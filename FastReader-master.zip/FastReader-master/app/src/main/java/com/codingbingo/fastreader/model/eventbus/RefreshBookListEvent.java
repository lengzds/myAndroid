package com.codingbingo.fastreader.model.eventbus;

/**
 * Author: bingo
 * Email: codingbingo@gmail.com
 * By 2017/4/8.
 * 刷新首页书籍列表事件
 */

public class RefreshBookListEvent {
    public RefreshBookListEvent() {
    }
}
