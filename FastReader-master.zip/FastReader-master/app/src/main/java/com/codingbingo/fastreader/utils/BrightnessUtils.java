package com.codingbingo.fastreader.utils;

/**
 * Author: bingo
 * Email: codingbingo@gmail.com
 * By 2017/4/12.
 *
 * 亮度调节
 */

public class BrightnessUtils {
}
