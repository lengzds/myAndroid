package com.codingbingo.fastreader.base.utils;

import java.util.logging.Logger;

/**
 * Author: bingo
 * Email: codingbingo@gmail.com
 * By 2017/1/15.
 */

public class BaseUtils {
    protected static Logger logger = Logger.getLogger(BaseUtils.class.getName());
}
