package com.codingbingo.fastreader.utils;

import android.util.Log;

/**
 * Author: bingo
 * Email: codingbingo@gmail.com
 * By 2017/2/14.
 */

public class LogUtils {

}
