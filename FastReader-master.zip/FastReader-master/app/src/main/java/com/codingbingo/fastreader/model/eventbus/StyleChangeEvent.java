package com.codingbingo.fastreader.model.eventbus;

/**
 * Author: bingo
 * Email: codingbingo@gmail.com
 * By 2017/4/11.
 * 书籍样式改变事件
 */

public class StyleChangeEvent {
    public StyleChangeEvent() {
    }
}
