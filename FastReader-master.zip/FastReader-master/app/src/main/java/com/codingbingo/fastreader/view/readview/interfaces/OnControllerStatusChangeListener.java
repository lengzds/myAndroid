package com.codingbingo.fastreader.view.readview.interfaces;

/**
 * Author: bingo
 * Email: codingbingo@gmail.com
 * By 2017/3/11.
 */
public interface OnControllerStatusChangeListener {
    void onControllerStatusChange(boolean isShowing);
}
