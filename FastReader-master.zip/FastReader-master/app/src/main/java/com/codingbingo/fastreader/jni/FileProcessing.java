package com.codingbingo.fastreader.jni;

/**
 * Created by bingo on 2017/1/4.
 */

public class FileProcessing {


    static {
        System.loadLibrary("BookProcessing");
    }
}
