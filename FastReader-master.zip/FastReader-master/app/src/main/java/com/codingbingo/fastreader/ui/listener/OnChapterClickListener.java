package com.codingbingo.fastreader.ui.listener;

/**
 * Author: bingo
 * Email: codingbingo@gmail.com
 * By 2017/4/18.
 */

public interface OnChapterClickListener {
    void onChapterClick(int chapter);
}
